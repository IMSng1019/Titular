package titular.modid.client;

import net.fabricmc.api.ClientModInitializer;

public class TitularClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}